<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Qonun extends Model
{
    
}
