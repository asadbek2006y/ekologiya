
<div class="col-lg-3 col-md-6 mb-5">
    <h5 class="mb-4 text-white text-uppercase font-weight-bold">Flickr Photos</h5>
    <div class="row">
<?php $__currentLoopData = $best; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $be): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="col-4 mb-3">
            <a href=""><img class="w-100" src="<?php echo e(asset("storage/".$be->img)); ?>" style="width:100px; height:100px;" alt=""></a>
        </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<?php /**PATH D:\OSPanel\domains\ekologiya\resources\views/footer.blade.php ENDPATH**/ ?>