<?php

return [
    'bosh'        => 'Home',
    "Qo'mita"     => 'Comittee',
    "Faoliyat"    => 'Activity',
    "Rahbariyat"  => 'Admistration',
    "Viloyat"     => 'Region',
    "Xisobotlar"  => 'Reports',
    "Aloqa"       => 'Contact',
    "Hujjatlar"   => 'Documents',
    "Yangiliklar" => 'News',
    "logo"        => "Department of the Ministry of Natural Resources, Syrdarya region",
    'title1'      => "Read the history of the Committee",
    'title2'      => "meet",
    'title3'      => "Check out our documentation",
    'title4'      => "Get acquainted with our activities",
    'title5'      => "Read News",
    'news'        => "Featured News",
    'contact'     => "Contact Form for Questions and Suggestions",
    "contactinfo" =>  "How to I connect",
    "example"     => "To contact us, enter your information in this contact form and write an application or offer in the message section",
    "adtitle"     => "Our Address",
    "address"     => "Uzbekistan, Gulistan, Birlashgan street 10",
    'etitle'      => "Email Us",
    'etitl'       => "2252049",
    "callus"      => "Call Us",
    "contactus"   => "Contact Us",
    "follow"      => "Подпишитесь на нас",
    "svyaz"       =>  "Подпишитесь на нас",


















];
