<?php

return [
    'bosh' => 'Bosh Sahifa',
    "Qo'mita" => "Qo'mita",
    "Faoliyat" => 'Faoliyat',
    "Rahbariyat" => 'Rahbariyat',
    "Viloyat" => 'Viloyat',
    "Xisobotlar" => 'Hisobotlar',
    "Aloqa" => 'Aloqa',
    "Hujjatlar" => 'Hujjatlar',
    "Yangiliklar" => 'Yangiliklar',
    "logo"        => "Tabiat resurslari vazirligi Sirdaryo viloyati Boshqarmasi",
    'title1'      => "Qo'mita Tarixi bilan",
    'title2'      => "tanishib chiqing ",
    'title3'      => "Hujjatlarni ko'rib chiqing",
    'title4'      => "Faoliyatimiz bilan tanishib chiqing",
    'title5'      => "Yangiliklarni o'qib chiqish",
    'news'        => "Tavsiya Etilatigan",
    'contact'     => "Savollar va Takliflar uchun Aloqa form",
    "contactinfo" =>  "Qanday bog'lanadi",
    "example"     => "Biz bilan bog'lanish uchun mana bu aloqa formiga ma'lumotlaringizni kritasiz va message qismiga ariza yoki taklif yozasiz",
    "adtitle"     => "Bizning Manzil",
    "address"     => "Birlashgan ko'chasi 10, Guliston,O'zbekiston",
    'etitle'      => "Elektron pochta bilan bog'lanish",
    'etitl'       => "2252049",
    "callus"      => "Bizga murojaat qiling",
    "contactus"   => "Bizga bilan bog'laning",
    "follow"      => "Bizga obuna bo'ling",
    "svyaz"       =>  "Bizga obuna bo'ling",

















];
