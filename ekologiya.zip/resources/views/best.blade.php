{{-- @foreach ($work as $w)

<div class="col-4 mb-3">
    <a href=""><img class="w-100" src="{{asset('storage')}}" alt=""></a>
</div>
@endforeach --}}
