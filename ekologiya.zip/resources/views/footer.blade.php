{{--
<div class="col-lg-3 col-md-6 mb-5">
    <h5 class="mb-4 text-white text-uppercase font-weight-bold">Flickr Photos</h5>
    <div class="row">
@foreach ($best as $be)

        <div class="col-4 mb-3">
            <a href=""><img class="w-100" src="{{asset("storage/".$be->img)}}" style="width:100px; height:100px;" alt=""></a>
        </div>
@endforeach
    </div>
</div>
 --}}
