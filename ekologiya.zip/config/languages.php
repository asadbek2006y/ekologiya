<?php

return [
    'en' => [
        'display' => 'English',
        'flag-icon' => 'us'
    ],
    'ru' => [
        'display' => 'Русский',
        'flag-icon' => 'ru'
    ],
    'uz' => [
        'display' => "O'zbekcha",
        'flag-icon' => 'uz'
    ],
];
